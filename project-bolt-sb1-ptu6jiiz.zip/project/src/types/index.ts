export interface Transaction {
  id: string;
  amount: number;
  merchant: string;
  date: string;
  status: 'approved' | 'declined' | 'flagged';
  riskScore: number;
  category: string;
  cardLast4: string;
  location: string;
  deviceUsed: string;
  notes?: string;
}

export interface Alert {
  id: string;
  type: 'high_risk' | 'unusual_location' | 'multiple_attempts' | 'large_transaction';
  message: string;
  date: string;
  transactionId: string;
  isRead: boolean;
}

export interface SecuritySetting {
  id: string;
  name: string;
  description: string;
  isEnabled: boolean;
}

export interface ChartData {
  label: string;
  value: number;
}