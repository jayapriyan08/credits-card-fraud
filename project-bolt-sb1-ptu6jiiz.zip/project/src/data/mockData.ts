import { Transaction, Alert, SecuritySetting, ChartData } from '../types';

// Mock transactions data
export const transactions: Transaction[] = [
  {
    id: '1',
    amount: 125.30,
    merchant: 'Amazon',
    date: '2025-03-15T14:32:23',
    status: 'approved',
    riskScore: 12,
    category: 'Shopping',
    cardLast4: '4382',
    location: 'Online',
    deviceUsed: 'Desktop - Chrome',
  },
  {
    id: '2',
    amount: 2499.99,
    merchant: 'Best Buy',
    date: '2025-03-14T11:15:45',
    status: 'flagged',
    riskScore: 78,
    category: 'Electronics',
    cardLast4: '4382',
    location: 'New York, NY',
    deviceUsed: 'Unknown Device',
    notes: 'Unusual location and high amount'
  },
  {
    id: '3',
    amount: 89.95,
    merchant: 'Uber',
    date: '2025-03-14T09:32:12',
    status: 'approved',
    riskScore: 15,
    category: 'Transportation',
    cardLast4: '4382',
    location: 'Boston, MA',
    deviceUsed: 'iPhone App',
  },
  {
    id: '4',
    amount: 1250.00,
    merchant: 'Flight Tickets Inc',
    date: '2025-03-13T16:45:33',
    status: 'approved',
    riskScore: 35,
    category: 'Travel',
    cardLast4: '4382',
    location: 'Online',
    deviceUsed: 'Desktop - Safari',
  },
  {
    id: '5',
    amount: 50.00,
    merchant: 'ATM Withdrawal',
    date: '2025-03-12T08:12:09',
    status: 'approved',
    riskScore: 8,
    category: 'Cash',
    cardLast4: '4382',
    location: 'Boston, MA',
    deviceUsed: 'ATM Terminal',
  },
  {
    id: '6',
    amount: 299.99,
    merchant: 'Unknown Merchant',
    date: '2025-03-11T23:59:59',
    status: 'declined',
    riskScore: 92,
    category: 'Unknown',
    cardLast4: '4382',
    location: 'Jakarta, Indonesia',
    deviceUsed: 'Unknown Device',
    notes: 'Suspicious location and unknown merchant'
  },
  {
    id: '7',
    amount: 79.99,
    merchant: 'Netflix',
    date: '2025-03-10T19:23:45',
    status: 'approved',
    riskScore: 5,
    category: 'Entertainment',
    cardLast4: '4382',
    location: 'Online',
    deviceUsed: 'Smart TV',
  },
];

// Mock alerts data
export const alerts: Alert[] = [
  {
    id: '1',
    type: 'high_risk',
    message: 'High-risk transaction of $2,499.99 at Best Buy',
    date: '2025-03-14T11:15:45',
    transactionId: '2',
    isRead: false,
  },
  {
    id: '2',
    type: 'unusual_location',
    message: 'Transaction attempted from unusual location: Jakarta, Indonesia',
    date: '2025-03-11T23:59:59',
    transactionId: '6',
    isRead: true,
  },
  {
    id: '3',
    type: 'multiple_attempts',
    message: 'Multiple failed transaction attempts detected',
    date: '2025-03-11T23:45:12',
    transactionId: '6',
    isRead: false,
  },
  {
    id: '4',
    type: 'large_transaction',
    message: 'Large transaction of $1,250.00 for Flight Tickets Inc',
    date: '2025-03-13T16:45:33',
    transactionId: '4',
    isRead: true,
  },
];

// Mock security settings
export const securitySettings: SecuritySetting[] = [
  {
    id: '1',
    name: 'Location-based Verification',
    description: 'Verify transactions from new or unusual locations',
    isEnabled: true,
  },
  {
    id: '2',
    name: 'Large Transaction Alerts',
    description: 'Get notified of transactions exceeding your set threshold',
    isEnabled: true,
  },
  {
    id: '3',
    name: 'International Transaction Block',
    description: 'Block transactions from outside your home country',
    isEnabled: false,
  },
  {
    id: '4',
    name: 'Device Verification',
    description: 'Verify transactions from new devices',
    isEnabled: true,
  },
  {
    id: '5',
    name: 'Real-time SMS Alerts',
    description: 'Receive SMS alerts for suspicious activity',
    isEnabled: true,
  },
];

// Mock chart data
export const riskDistributionData: ChartData[] = [
  { label: 'Low Risk', value: 65 },
  { label: 'Medium Risk', value: 25 },
  { label: 'High Risk', value: 10 },
];

export const transactionsByCategoryData: ChartData[] = [
  { label: 'Shopping', value: 35 },
  { label: 'Electronics', value: 20 },
  { label: 'Food & Dining', value: 15 },
  { label: 'Travel', value: 10 },
  { label: 'Entertainment', value: 10 },
  { label: 'Other', value: 10 },
];

export const transactionsByDayData: ChartData[] = [
  { label: 'Mon', value: 12 },
  { label: 'Tue', value: 19 },
  { label: 'Wed', value: 15 },
  { label: 'Thu', value: 22 },
  { label: 'Fri', value: 35 },
  { label: 'Sat', value: 28 },
  { label: 'Sun', value: 18 },
];