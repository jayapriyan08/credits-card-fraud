/**
 * Format a number as a currency string
 */
export const formatCurrency = (amount: number): string => {
  return new Intl.NumberFormat('en-US', {
    style: 'currency',
    currency: 'USD',
    minimumFractionDigits: 2,
  }).format(amount);
};

/**
 * Format a date string into a readable format
 */
export const formatDate = (dateString: string): string => {
  const date = new Date(dateString);
  return new Intl.DateTimeFormat('en-US', {
    month: 'short',
    day: 'numeric',
    year: 'numeric',
    hour: 'numeric',
    minute: 'numeric',
  }).format(date);
};

/**
 * Returns a color based on risk score
 */
export const getRiskColor = (score: number): string => {
  if (score < 20) return 'bg-green-100 text-green-800';
  if (score < 50) return 'bg-yellow-100 text-yellow-800';
  if (score < 80) return 'bg-orange-100 text-orange-800';
  return 'bg-red-100 text-red-800';
};

/**
 * Returns a descriptive text based on risk score
 */
export const getRiskLabel = (score: number): string => {
  if (score < 20) return 'Low';
  if (score < 50) return 'Medium';
  if (score < 80) return 'High';
  return 'Very High';
};

/**
 * Gets a status badge class based on status
 */
export const getStatusBadgeClass = (status: string): string => {
  switch (status) {
    case 'approved':
      return 'bg-green-100 text-green-800';
    case 'declined':
      return 'bg-red-100 text-red-800';
    case 'flagged':
      return 'bg-yellow-100 text-yellow-800';
    default:
      return 'bg-gray-100 text-gray-800';
  }
};

/**
 * Returns alert icon color based on type
 */
export const getAlertTypeColor = (type: string): string => {
  switch (type) {
    case 'high_risk':
      return 'text-red-500';
    case 'unusual_location':
      return 'text-purple-500';
    case 'multiple_attempts':
      return 'text-orange-500';
    case 'large_transaction':
      return 'text-blue-500';
    default:
      return 'text-gray-500';
  }
};