import React, { useState } from 'react';
import Card, { CardHeader, CardContent } from '../components/ui/Card';
import { transactions } from '../data/mockData';
import TransactionTable from '../components/dashboard/TransactionTable';
import Button from '../components/ui/Button';
import { Search, Filter, Calendar, CreditCard } from 'lucide-react';

const Transactions: React.FC = () => {
  const [searchQuery, setSearchQuery] = useState('');
  const [statusFilter, setStatusFilter] = useState<string>('all');
  
  // Filter transactions based on search query and status filter
  const filteredTransactions = transactions.filter(t => {
    const matchesSearch = t.merchant.toLowerCase().includes(searchQuery.toLowerCase()) ||
                          t.category.toLowerCase().includes(searchQuery.toLowerCase());
    
    const matchesStatus = statusFilter === 'all' || t.status === statusFilter;
    
    return matchesSearch && matchesStatus;
  });

  return (
    <div className="py-6">
      <div className="px-4 sm:px-6 md:px-8">
        <h1 className="text-2xl font-semibold text-gray-900">Transactions</h1>
        <p className="mt-1 text-sm text-gray-600">
          View and manage all your card transactions.
        </p>

        <Card className="mt-6">
          <CardHeader className="border-b">
            <div className="flex flex-col md:flex-row md:items-center md:justify-between space-y-3 md:space-y-0">
              <h3 className="text-lg font-medium leading-6 text-gray-900">Transaction History</h3>
              
              <div className="flex space-x-2">
                <div className="relative rounded-md shadow-sm">
                  <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                    <Search className="h-4 w-4 text-gray-400" />
                  </div>
                  <input
                    type="text"
                    className="focus:ring-blue-500 focus:border-blue-500 block w-full pl-10 sm:text-sm border-gray-300 rounded-md"
                    placeholder="Search..."
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                  />
                </div>
                
                <div className="relative">
                  <select
                    className="focus:ring-blue-500 focus:border-blue-500 h-full py-2 pl-3 pr-8 border-gray-300 bg-white text-gray-700 sm:text-sm rounded-md"
                    value={statusFilter}
                    onChange={(e) => setStatusFilter(e.target.value)}
                  >
                    <option value="all">All Status</option>
                    <option value="approved">Approved</option>
                    <option value="declined">Declined</option>
                    <option value="flagged">Flagged</option>
                  </select>
                </div>
              </div>
            </div>
          </CardHeader>
          
          <div className="border-b border-gray-200 bg-gray-50 px-4 py-4 sm:px-6">
            <div className="flex flex-wrap items-center justify-between sm:flex-nowrap">
              <div>
                <p className="text-sm text-gray-500">
                  Showing <span className="font-medium text-gray-900">{filteredTransactions.length}</span> transactions
                </p>
              </div>
              <div className="flex space-x-2">
                <Button variant="outline" size="sm" className="flex items-center">
                  <Filter className="h-4 w-4 mr-1.5" />
                  <span>Filter</span>
                </Button>
                <Button variant="outline" size="sm" className="flex items-center">
                  <Calendar className="h-4 w-4 mr-1.5" />
                  <span>Date Range</span>
                </Button>
                <Button variant="outline" size="sm" className="flex items-center">
                  <CreditCard className="h-4 w-4 mr-1.5" />
                  <span>Cards</span>
                </Button>
              </div>
            </div>
          </div>
          
          <div className="overflow-hidden">
            {filteredTransactions.length > 0 ? (
              <TransactionTable transactions={filteredTransactions} />
            ) : (
              <div className="text-center py-16">
                <Search className="mx-auto h-12 w-12 text-gray-400" />
                <h3 className="mt-2 text-sm font-medium text-gray-900">No transactions found</h3>
                <p className="mt-1 text-sm text-gray-500">
                  Try adjusting your search or filter to find what you're looking for.
                </p>
              </div>
            )}
          </div>
        </Card>
      </div>
    </div>
  );
};

export default Transactions;