import React from 'react';
import Card, { CardHeader, CardContent } from '../components/ui/Card';
import Button from '../components/ui/Button';
import DonutChart from '../components/charts/DonutChart';
import BarChart from '../components/charts/BarChart';
import { 
  riskDistributionData, 
  transactionsByCategoryData,
  transactionsByDayData
} from '../data/mockData';
import { FileText, Download, Calendar, Sliders } from 'lucide-react';

const Reports: React.FC = () => {
  return (
    <div className="py-6">
      <div className="px-4 sm:px-6 md:px-8">
        <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between">
          <div>
            <h1 className="text-2xl font-semibold text-gray-900">Reports</h1>
            <p className="mt-1 text-sm text-gray-600">
              View and download your transaction reports and analytics.
            </p>
          </div>
          <div className="mt-4 sm:mt-0 flex space-x-3">
            <Button variant="outline" size="sm" className="flex items-center">
              <Calendar className="h-4 w-4 mr-1.5" />
              <span>Last 30 Days</span>
            </Button>
            <Button size="sm" className="flex items-center">
              <Download className="h-4 w-4 mr-1.5" />
              <span>Export</span>
            </Button>
          </div>
        </div>

        {/* Charts Row */}
        <div className="mt-6 grid grid-cols-1 gap-5 lg:grid-cols-2">
          <Card>
            <CardHeader className="flex justify-between items-center">
              <h3 className="text-lg font-medium leading-6 text-gray-900">Transaction Categories</h3>
              <Button variant="ghost" size="sm">
                <Sliders className="h-4 w-4 mr-1.5" />
                <span>Filter</span>
              </Button>
            </CardHeader>
            <CardContent>
              <DonutChart data={transactionsByCategoryData} title="" className="h-80" />
            </CardContent>
          </Card>
          
          <Card>
            <CardHeader className="flex justify-between items-center">
              <h3 className="text-lg font-medium leading-6 text-gray-900">Transactions by Day</h3>
              <Button variant="ghost" size="sm">
                <Sliders className="h-4 w-4 mr-1.5" />
                <span>Filter</span>
              </Button>
            </CardHeader>
            <CardContent>
              <BarChart data={transactionsByDayData} title="" className="h-80" color="#6366F1" />
            </CardContent>
          </Card>
        </div>

        {/* Available Reports */}
        <Card className="mt-6">
          <CardHeader>
            <h3 className="text-lg font-medium leading-6 text-gray-900">Available Reports</h3>
          </CardHeader>
          <div className="border-t border-gray-200 divide-y divide-gray-200">
            {[
              {
                title: 'March 2025 Transaction Summary',
                description: 'Complete summary of all transactions from March 2025',
                date: 'Generated: April 1, 2025',
                icon: <FileText className="h-5 w-5 text-blue-500" />,
              },
              {
                title: 'February 2025 Transaction Summary',
                description: 'Complete summary of all transactions from February 2025',
                date: 'Generated: March 1, 2025',
                icon: <FileText className="h-5 w-5 text-blue-500" />,
              },
              {
                title: 'January 2025 Transaction Summary',
                description: 'Complete summary of all transactions from January 2025',
                date: 'Generated: February 1, 2025',
                icon: <FileText className="h-5 w-5 text-blue-500" />,
              },
              {
                title: 'Q1 2025 Security Insights',
                description: 'Analysis of security events and fraud prevention measures',
                date: 'Generated: April 5, 2025',
                icon: <FileText className="h-5 w-5 text-purple-500" />,
              },
            ].map((report, index) => (
              <div key={index} className="px-6 py-4 flex items-center justify-between">
                <div className="flex items-start space-x-3">
                  <div className="flex-shrink-0 mt-1">
                    {report.icon}
                  </div>
                  <div>
                    <h4 className="text-sm font-medium text-gray-900">{report.title}</h4>
                    <p className="text-sm text-gray-500">{report.description}</p>
                    <p className="text-xs text-gray-400 mt-1">{report.date}</p>
                  </div>
                </div>
                <Button size="sm" variant="outline" className="flex items-center">
                  <Download className="h-4 w-4 mr-1.5" />
                  <span>Download</span>
                </Button>
              </div>
            ))}
          </div>
        </Card>
      </div>
    </div>
  );
};

export default Reports;