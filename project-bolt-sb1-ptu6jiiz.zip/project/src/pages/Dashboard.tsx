import React from 'react';
import Card, { CardHeader, CardContent } from '../components/ui/Card';
import DonutChart from '../components/charts/DonutChart';
import BarChart from '../components/charts/BarChart';
import { 
  riskDistributionData, 
  transactionsByCategoryData, 
  transactionsByDayData,
  transactions 
} from '../data/mockData';
import { CreditCard, TrendingUp, ShieldAlert, DollarSign } from 'lucide-react';
import Button from '../components/ui/Button';
import TransactionTable from '../components/dashboard/TransactionTable';

const Dashboard: React.FC = () => {
  // Calculate total and flagged transactions
  const totalTransactions = transactions.length;
  const flaggedTransactions = transactions.filter(t => t.status === 'flagged').length;
  const declinedTransactions = transactions.filter(t => t.status === 'declined').length;
  
  // Calculate total amount
  const totalAmount = transactions.reduce((sum, t) => sum + t.amount, 0);
  
  // Format as currency
  const formatCurrency = (amount: number) => {
    return new Intl.NumberFormat('en-US', {
      style: 'currency',
      currency: 'USD',
      minimumFractionDigits: 2,
    }).format(amount);
  };

  return (
    <div className="py-6">
      <div className="px-4 sm:px-6 md:px-8">
        <h1 className="text-2xl font-semibold text-gray-900">Dashboard</h1>
        <p className="mt-1 text-sm text-gray-600">
          Monitor your account activity and security status.
        </p>

        {/* Stats cards */}
        <div className="mt-6 grid grid-cols-1 gap-5 sm:grid-cols-2 lg:grid-cols-4">
          {/* Total Transactions */}
          <Card>
            <CardContent className="py-5">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-gray-600 truncate">
                    Total Transactions
                  </p>
                  <p className="mt-1 text-3xl font-semibold text-gray-900">
                    {totalTransactions}
                  </p>
                </div>
                <div className="flex items-center justify-center w-12 h-12 rounded-full bg-blue-100 text-blue-600">
                  <CreditCard className="h-6 w-6" />
                </div>
              </div>
              <div className="mt-3 flex items-center text-sm">
                <TrendingUp className="h-4 w-4 text-green-500 mr-1.5" />
                <span className="text-green-600 font-medium">12% increase</span>
                <span className="text-gray-500 ml-1.5">from last month</span>
              </div>
            </CardContent>
          </Card>

          {/* Flagged Transactions */}
          <Card>
            <CardContent className="py-5">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-gray-600 truncate">
                    Flagged Transactions
                  </p>
                  <p className="mt-1 text-3xl font-semibold text-gray-900">
                    {flaggedTransactions}
                  </p>
                </div>
                <div className="flex items-center justify-center w-12 h-12 rounded-full bg-yellow-100 text-yellow-600">
                  <ShieldAlert className="h-6 w-6" />
                </div>
              </div>
              <div className="mt-3 flex items-center text-sm">
                <span className="text-yellow-600 font-medium">{Math.round((flaggedTransactions / totalTransactions) * 100)}% of total</span>
                <span className="text-gray-500 ml-1.5">needs review</span>
              </div>
            </CardContent>
          </Card>

          {/* Declined Transactions */}
          <Card>
            <CardContent className="py-5">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-gray-600 truncate">
                    Declined Transactions
                  </p>
                  <p className="mt-1 text-3xl font-semibold text-gray-900">
                    {declinedTransactions}
                  </p>
                </div>
                <div className="flex items-center justify-center w-12 h-12 rounded-full bg-red-100 text-red-600">
                  <ShieldAlert className="h-6 w-6" />
                </div>
              </div>
              <div className="mt-3 flex items-center text-sm">
                <span className="text-red-600 font-medium">{Math.round((declinedTransactions / totalTransactions) * 100)}% of total</span>
                <span className="text-gray-500 ml-1.5">blocked for security</span>
              </div>
            </CardContent>
          </Card>

          {/* Total Amount */}
          <Card>
            <CardContent className="py-5">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-gray-600 truncate">
                    Total Amount
                  </p>
                  <p className="mt-1 text-3xl font-semibold text-gray-900">
                    {formatCurrency(totalAmount)}
                  </p>
                </div>
                <div className="flex items-center justify-center w-12 h-12 rounded-full bg-green-100 text-green-600">
                  <DollarSign className="h-6 w-6" />
                </div>
              </div>
              <div className="mt-3 flex items-center text-sm">
                <TrendingUp className="h-4 w-4 text-green-500 mr-1.5" />
                <span className="text-green-600 font-medium">8% increase</span>
                <span className="text-gray-500 ml-1.5">from last month</span>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Charts Row */}
        <div className="mt-6 grid grid-cols-1 gap-5 lg:grid-cols-3">
          <Card className="lg:col-span-1">
            <CardHeader>
              <h3 className="text-lg font-medium leading-6 text-gray-900">Risk Distribution</h3>
            </CardHeader>
            <CardContent>
              <DonutChart data={riskDistributionData} title="" className="h-60" />
            </CardContent>
          </Card>
          
          <Card className="lg:col-span-2">
            <CardHeader>
              <h3 className="text-lg font-medium leading-6 text-gray-900">Transactions by Day</h3>
            </CardHeader>
            <CardContent>
              <BarChart data={transactionsByDayData} title="" className="h-60" color="#4F46E5" />
            </CardContent>
          </Card>
        </div>

        {/* Recent Transactions */}
        <div className="mt-6">
          <Card>
            <CardHeader className="flex justify-between items-center">
              <h3 className="text-lg font-medium leading-6 text-gray-900">Recent Transactions</h3>
              <Button variant="outline" size="sm">View All</Button>
            </CardHeader>
            <div className="overflow-hidden">
              <TransactionTable transactions={transactions.slice(0, 5)} />
            </div>
          </Card>
        </div>
      </div>
    </div>
  );
};

export default Dashboard;