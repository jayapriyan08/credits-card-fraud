import React, { useState } from 'react';
import Card, { CardHeader, CardContent } from '../components/ui/Card';
import { securitySettings as mockSettings } from '../data/mockData';
import SecuritySettings from '../components/dashboard/SecuritySettings';
import Button from '../components/ui/Button';
import { LockKeyhole, CreditCard, Shield, Smartphone, MapPin } from 'lucide-react';

const Security: React.FC = () => {
  const [securitySettings, setSecuritySettings] = useState(mockSettings);

  const handleToggle = (id: string) => {
    setSecuritySettings(securitySettings.map(setting => 
      setting.id === id ? { ...setting, isEnabled: !setting.isEnabled } : setting
    ));
  };

  return (
    <div className="py-6">
      <div className="px-4 sm:px-6 md:px-8">
        <h1 className="text-2xl font-semibold text-gray-900">Security Settings</h1>
        <p className="mt-1 text-sm text-gray-600">
          Manage your security preferences and fraud protection settings.
        </p>

        <div className="mt-6 grid grid-cols-1 gap-5 sm:grid-cols-2 lg:grid-cols-3">
          <Card>
            <CardContent className="py-5">
              <div className="flex items-center space-x-4">
                <div className="flex items-center justify-center w-10 h-10 rounded-full bg-blue-100 text-blue-600">
                  <LockKeyhole className="h-5 w-5" />
                </div>
                <div>
                  <h3 className="text-lg font-medium text-gray-900">Account Protection</h3>
                  <p className="text-sm text-gray-500">AI-powered fraud detection active</p>
                </div>
              </div>
            </CardContent>
          </Card>
          
          <Card>
            <CardContent className="py-5">
              <div className="flex items-center space-x-4">
                <div className="flex items-center justify-center w-10 h-10 rounded-full bg-green-100 text-green-600">
                  <CreditCard className="h-5 w-5" />
                </div>
                <div>
                  <h3 className="text-lg font-medium text-gray-900">Card Security</h3>
                  <p className="text-sm text-gray-500">3 cards actively monitored</p>
                </div>
              </div>
            </CardContent>
          </Card>
          
          <Card>
            <CardContent className="py-5">
              <div className="flex items-center space-x-4">
                <div className="flex items-center justify-center w-10 h-10 rounded-full bg-purple-100 text-purple-600">
                  <Shield className="h-5 w-5" />
                </div>
                <div>
                  <h3 className="text-lg font-medium text-gray-900">Security Score</h3>
                  <p className="text-sm text-gray-500">92/100 - Excellent</p>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>

        <Card className="mt-6">
          <CardHeader>
            <h3 className="text-lg font-medium leading-6 text-gray-900">Security Preferences</h3>
          </CardHeader>
          <CardContent>
            <SecuritySettings settings={securitySettings} onToggle={handleToggle} />
          </CardContent>
        </Card>

        <div className="mt-6 grid grid-cols-1 gap-5 lg:grid-cols-2">
          <Card>
            <CardHeader>
              <h3 className="text-lg font-medium leading-6 text-gray-900">Trusted Devices</h3>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <div className="flex justify-between items-center pb-4 border-b border-gray-100">
                  <div className="flex items-start space-x-3">
                    <Smartphone className="h-5 w-5 text-gray-400 mt-0.5" />
                    <div>
                      <h4 className="text-sm font-medium text-gray-900">iPhone 15 Pro</h4>
                      <p className="text-xs text-gray-500">Last used: Today at 09:32 AM</p>
                      <p className="text-xs text-gray-500">Boston, MA</p>
                    </div>
                  </div>
                  <Badge text="Current Device" className="bg-green-100 text-green-800" />
                </div>
                
                <div className="flex justify-between items-center pb-4 border-b border-gray-100">
                  <div className="flex items-start space-x-3">
                    <Smartphone className="h-5 w-5 text-gray-400 mt-0.5" />
                    <div>
                      <h4 className="text-sm font-medium text-gray-900">MacBook Pro</h4>
                      <p className="text-xs text-gray-500">Last used: Yesterday at 3:45 PM</p>
                      <p className="text-xs text-gray-500">Boston, MA</p>
                    </div>
                  </div>
                  <Button variant="outline" size="sm">Remove</Button>
                </div>
                
                <div className="flex justify-between items-center">
                  <div className="flex items-start space-x-3">
                    <Smartphone className="h-5 w-5 text-gray-400 mt-0.5" />
                    <div>
                      <h4 className="text-sm font-medium text-gray-900">Windows PC</h4>
                      <p className="text-xs text-gray-500">Last used: March 10, 2025 at 11:23 AM</p>
                      <p className="text-xs text-gray-500">Boston, MA</p>
                    </div>
                  </div>
                  <Button variant="outline" size="sm">Remove</Button>
                </div>
              </div>
            </CardContent>
          </Card>
          
          <Card>
            <CardHeader>
              <h3 className="text-lg font-medium leading-6 text-gray-900">Trusted Locations</h3>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <div className="flex justify-between items-center pb-4 border-b border-gray-100">
                  <div className="flex items-start space-x-3">
                    <MapPin className="h-5 w-5 text-gray-400 mt-0.5" />
                    <div>
                      <h4 className="text-sm font-medium text-gray-900">Boston, MA</h4>
                      <p className="text-xs text-gray-500">Added: January 15, 2025</p>
                    </div>
                  </div>
                  <Badge text="Primary Location" className="bg-blue-100 text-blue-800" />
                </div>
                
                <div className="flex justify-between items-center pb-4 border-b border-gray-100">
                  <div className="flex items-start space-x-3">
                    <MapPin className="h-5 w-5 text-gray-400 mt-0.5" />
                    <div>
                      <h4 className="text-sm font-medium text-gray-900">New York, NY</h4>
                      <p className="text-xs text-gray-500">Added: February 22, 2025</p>
                    </div>
                  </div>
                  <Button variant="outline" size="sm">Remove</Button>
                </div>
                
                <div className="pt-2">
                  <Button variant="outline" size="sm">
                    <MapPin className="h-4 w-4 mr-1.5" />
                    Add New Location
                  </Button>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
};

export default Security;