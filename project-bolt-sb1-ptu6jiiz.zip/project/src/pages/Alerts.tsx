import React, { useState } from 'react';
import Card, { CardHeader, CardContent } from '../components/ui/Card';
import { alerts as mockAlerts } from '../data/mockData';
import AlertsList from '../components/dashboard/AlertsList';
import Badge from '../components/ui/Badge';
import Button from '../components/ui/Button';
import { Bell, CheckCircle } from 'lucide-react';

const Alerts: React.FC = () => {
  const [alerts, setAlerts] = useState(mockAlerts);

  const handleMarkAsRead = (id: string) => {
    setAlerts(alerts.map(alert => 
      alert.id === id ? { ...alert, isRead: true } : alert
    ));
  };

  const handleMarkAllAsRead = () => {
    setAlerts(alerts.map(alert => ({ ...alert, isRead: true })));
  };

  const unreadCount = alerts.filter(alert => !alert.isRead).length;

  return (
    <div className="py-6">
      <div className="px-4 sm:px-6 md:px-8">
        <div className="flex justify-between items-start">
          <div>
            <h1 className="text-2xl font-semibold text-gray-900">Alerts</h1>
            <p className="mt-1 text-sm text-gray-600">
              Stay informed about suspicious activity on your account.
            </p>
          </div>
          
          <div className="flex items-center space-x-2">
            <Badge 
              text={`${unreadCount} unread`} 
              className={`${unreadCount > 0 ? 'bg-red-100 text-red-800' : 'bg-gray-100 text-gray-800'}`} 
            />
            {unreadCount > 0 && (
              <Button size="sm" variant="outline" onClick={handleMarkAllAsRead}>
                <CheckCircle className="h-4 w-4 mr-1.5" />
                Mark all as read
              </Button>
            )}
          </div>
        </div>

        <Card className="mt-6">
          <CardHeader className="flex justify-between items-center">
            <h3 className="text-lg font-medium leading-6 text-gray-900">Recent Alerts</h3>
            <Button variant="outline" size="sm">Alert Settings</Button>
          </CardHeader>
          <CardContent>
            {alerts.length > 0 ? (
              <AlertsList alerts={alerts} onMarkAsRead={handleMarkAsRead} />
            ) : (
              <div className="text-center py-16">
                <Bell className="mx-auto h-12 w-12 text-gray-400" />
                <h3 className="mt-2 text-sm font-medium text-gray-900">No alerts</h3>
                <p className="mt-1 text-sm text-gray-500">
                  You're all caught up! We'll notify you when there's suspicious activity.
                </p>
              </div>
            )}
          </CardContent>
        </Card>

        <Card className="mt-6">
          <CardHeader>
            <h3 className="text-lg font-medium leading-6 text-gray-900">Alert Preferences</h3>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <div>
                  <h4 className="text-sm font-medium text-gray-900">Email Notifications</h4>
                  <p className="text-sm text-gray-500">Get alerts delivered to your email</p>
                </div>
                <button 
                  type="button"
                  role="switch"
                  aria-checked={true}
                  className="relative inline-flex h-6 w-11 flex-shrink-0 cursor-pointer rounded-full border-2 border-transparent bg-blue-600 transition-colors duration-200"
                >
                  <span className="pointer-events-none inline-block h-5 w-5 transform rounded-full bg-white shadow ring-0 transition duration-200 ease-in-out translate-x-5" />
                </button>
              </div>
              
              <div className="flex items-center justify-between">
                <div>
                  <h4 className="text-sm font-medium text-gray-900">SMS Notifications</h4>
                  <p className="text-sm text-gray-500">Get alerts delivered to your phone</p>
                </div>
                <button 
                  type="button"
                  role="switch"
                  aria-checked={true}
                  className="relative inline-flex h-6 w-11 flex-shrink-0 cursor-pointer rounded-full border-2 border-transparent bg-blue-600 transition-colors duration-200"
                >
                  <span className="pointer-events-none inline-block h-5 w-5 transform rounded-full bg-white shadow ring-0 transition duration-200 ease-in-out translate-x-5" />
                </button>
              </div>
              
              <div className="flex items-center justify-between">
                <div>
                  <h4 className="text-sm font-medium text-gray-900">Push Notifications</h4>
                  <p className="text-sm text-gray-500">Get alerts delivered to your devices</p>
                </div>
                <button 
                  type="button"
                  role="switch"
                  aria-checked={false}
                  className="relative inline-flex h-6 w-11 flex-shrink-0 cursor-pointer rounded-full border-2 border-transparent bg-gray-200 transition-colors duration-200"
                >
                  <span className="pointer-events-none inline-block h-5 w-5 transform rounded-full bg-white shadow ring-0 transition duration-200 ease-in-out translate-x-0" />
                </button>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
};

export default Alerts;