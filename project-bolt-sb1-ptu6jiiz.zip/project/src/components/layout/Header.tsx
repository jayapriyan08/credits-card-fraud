import React, { useState, useEffect } from 'react';
import { Bell, Menu, X, User, Shield, Settings, CreditCard, LogOut } from 'lucide-react';
import { alerts } from '../../data/mockData';

interface HeaderProps {
  toggleSidebar: () => void;
  isSidebarOpen: boolean;
}

const Header: React.FC<HeaderProps> = ({ toggleSidebar, isSidebarOpen }) => {
  const [isScrolled, setIsScrolled] = useState(false);
  const [profileOpen, setProfileOpen] = useState(false);
  const [notificationsOpen, setNotificationsOpen] = useState(false);
  
  const unreadAlerts = alerts.filter(alert => !alert.isRead).length;

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 10);
    };
    
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  return (
    <header 
      className={`
        sticky top-0 z-10 transition-all duration-200
        ${isScrolled ? 'bg-white shadow-sm' : 'bg-transparent'}
      `}
    >
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between h-16">
          <div className="flex items-center">
            <button
              type="button"
              className="p-2 rounded-md text-gray-500 hover:text-gray-600 hover:bg-gray-100 focus:outline-none focus:ring-2 focus:ring-inset focus:ring-blue-500 md:hidden"
              onClick={toggleSidebar}
            >
              {isSidebarOpen ? (
                <X className="h-6 w-6" />
              ) : (
                <Menu className="h-6 w-6" />
              )}
            </button>
            <div className="flex items-center">
              <Shield className="h-8 w-8 text-blue-600" />
              <span className="ml-2 text-xl font-bold text-gray-900">FraudShield</span>
            </div>
          </div>
          
          <div className="flex items-center">
            <div className="relative">
              <button
                type="button"
                className="p-1 relative rounded-full text-gray-500 hover:text-gray-600 hover:bg-gray-100 focus:outline-none focus:ring-2 focus:ring-blue-500"
                onClick={() => {
                  setNotificationsOpen(!notificationsOpen);
                  if (profileOpen) setProfileOpen(false);
                }}
              >
                <Bell className="h-6 w-6" />
                {unreadAlerts > 0 && (
                  <span className="absolute top-0 right-0 block h-2 w-2 rounded-full bg-red-500 ring-2 ring-white" />
                )}
              </button>
              
              {notificationsOpen && (
                <div className="origin-top-right absolute right-0 mt-2 w-80 rounded-md shadow-lg bg-white ring-1 ring-black ring-opacity-5 focus:outline-none">
                  <div className="py-2 px-4 border-b border-gray-100">
                    <div className="flex justify-between items-center">
                      <h3 className="text-sm font-medium text-gray-900">Notifications</h3>
                      {unreadAlerts > 0 && (
                        <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-red-100 text-red-800">
                          {unreadAlerts} new
                        </span>
                      )}
                    </div>
                  </div>
                  <div className="max-h-60 overflow-y-auto p-2">
                    {alerts.slice(0, 3).map(alert => (
                      <div key={alert.id} className={`p-2 rounded-md mb-1 text-sm ${!alert.isRead ? 'bg-blue-50' : ''}`}>
                        <div className="font-medium text-gray-900">{alert.message}</div>
                        <div className="text-xs text-gray-500 mt-1">
                          {new Date(alert.date).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                        </div>
                      </div>
                    ))}
                  </div>
                  <div className="py-2 px-4 border-t border-gray-100">
                    <a href="#" className="text-sm font-medium text-blue-600 hover:text-blue-500">
                      View all notifications
                    </a>
                  </div>
                </div>
              )}
            </div>
            
            <div className="relative ml-3">
              <button
                type="button"
                className="flex items-center max-w-xs rounded-full bg-gray-800 text-sm focus:outline-none focus:ring-2 focus:ring-blue-500 focus:ring-offset-2"
                onClick={() => {
                  setProfileOpen(!profileOpen);
                  if (notificationsOpen) setNotificationsOpen(false);
                }}
              >
                <span className="sr-only">Open user menu</span>
                <div className="h-8 w-8 rounded-full bg-blue-600 flex items-center justify-center text-white">
                  <User className="h-4 w-4" />
                </div>
              </button>
              
              {profileOpen && (
                <div className="origin-top-right absolute right-0 mt-2 w-48 rounded-md shadow-lg bg-white ring-1 ring-black ring-opacity-5 focus:outline-none">
                  <div className="py-1">
                    <a href="#" className="flex items-center px-4 py-2 text-sm text-gray-700 hover:bg-gray-100">
                      <User className="mr-3 h-4 w-4 text-gray-500" />
                      Your Profile
                    </a>
                    <a href="#" className="flex items-center px-4 py-2 text-sm text-gray-700 hover:bg-gray-100">
                      <CreditCard className="mr-3 h-4 w-4 text-gray-500" />
                      Your Cards
                    </a>
                    <a href="#" className="flex items-center px-4 py-2 text-sm text-gray-700 hover:bg-gray-100">
                      <Settings className="mr-3 h-4 w-4 text-gray-500" />
                      Settings
                    </a>
                    <a href="#" className="flex items-center px-4 py-2 text-sm text-gray-700 hover:bg-gray-100">
                      <LogOut className="mr-3 h-4 w-4 text-gray-500" />
                      Sign out
                    </a>
                  </div>
                </div>
              )}
            </div>
          </div>
        </div>
      </div>
    </header>
  );
};

export default Header;