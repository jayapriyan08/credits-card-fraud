import React from 'react';
import { 
  LayoutDashboard, 
  CreditCard, 
  Bell, 
  Shield, 
  FileText, 
  HelpCircle, 
  Settings, 
  ChevronRight, 
  Lock
} from 'lucide-react';

interface SidebarProps {
  isOpen: boolean;
  activeTab: string;
  setActiveTab: (tab: string) => void;
}

const Sidebar: React.FC<SidebarProps> = ({ isOpen, activeTab, setActiveTab }) => {
  const navItems = [
    { id: 'dashboard', label: 'Dashboard', icon: <LayoutDashboard size={20} /> },
    { id: 'transactions', label: 'Transactions', icon: <CreditCard size={20} /> },
    { id: 'alerts', label: 'Alerts', icon: <Bell size={20} /> },
    { id: 'security', label: 'Security Settings', icon: <Shield size={20} /> },
    { id: 'reports', label: 'Reports', icon: <FileText size={20} /> }
  ];
  
  const supportItems = [
    { id: 'help', label: 'Help Center', icon: <HelpCircle size={20} /> },
    { id: 'settings', label: 'Settings', icon: <Settings size={20} /> }
  ];

  return (
    <div 
      className={`
        fixed inset-y-0 left-0 z-20 transform md:relative md:translate-x-0 transition duration-200 ease-in-out
        ${isOpen ? 'translate-x-0' : '-translate-x-full'}
        md:flex md:flex-col md:flex-shrink-0 md:w-64 bg-white border-r border-gray-200
      `}
    >
      <div className="h-0 flex-1 flex flex-col pt-5 pb-4 overflow-y-auto">
        <div className="flex-shrink-0 flex items-center px-4">
          <Shield className="h-8 w-8 text-blue-600" />
          <span className="ml-2 text-xl font-bold text-gray-900">FraudShield</span>
        </div>
        <div className="mt-6 px-4">
          <div className="bg-blue-50 rounded-lg p-4">
            <div className="flex">
              <div className="flex-shrink-0">
                <Lock className="h-6 w-6 text-blue-600" />
              </div>
              <div className="ml-3">
                <h3 className="text-sm font-medium text-blue-800">
                  Advanced Protection
                </h3>
                <div className="mt-2 text-sm text-blue-700">
                  <p>Your account is protected with our advanced AI detection system.</p>
                </div>
                <div className="mt-3">
                  <a href="#" className="text-sm font-medium text-blue-600 hover:text-blue-500 flex items-center">
                    View details
                    <ChevronRight className="ml-1 h-4 w-4" />
                  </a>
                </div>
              </div>
            </div>
          </div>
        </div>
        <nav className="mt-6 px-2 space-y-1">
          {navItems.map((item) => (
            <a
              key={item.id}
              href="#"
              onClick={(e) => {
                e.preventDefault();
                setActiveTab(item.id);
              }}
              className={`
                group flex items-center px-3 py-2 text-sm font-medium rounded-md transition duration-150 ease-in-out
                ${activeTab === item.id 
                  ? 'bg-blue-50 text-blue-700 border-l-4 border-blue-600' 
                  : 'text-gray-600 hover:bg-gray-50 hover:text-gray-900'
                }
              `}
            >
              <span 
                className={`mr-3 flex-shrink-0 ${activeTab === item.id ? 'text-blue-600' : 'text-gray-400 group-hover:text-gray-500'}`}
              >
                {item.icon}
              </span>
              {item.label}
            </a>
          ))}
        </nav>
      </div>
      <div className="flex-shrink-0 border-t border-gray-200 p-4">
        <div className="space-y-1">
          {supportItems.map((item) => (
            <a
              key={item.id}
              href="#"
              className="group flex items-center px-3 py-2 text-sm font-medium text-gray-600 rounded-md hover:text-gray-900 hover:bg-gray-50"
            >
              <span className="mr-3 flex-shrink-0 text-gray-400 group-hover:text-gray-500">
                {item.icon}
              </span>
              {item.label}
            </a>
          ))}
        </div>
      </div>
    </div>
  );
};

export default Sidebar;