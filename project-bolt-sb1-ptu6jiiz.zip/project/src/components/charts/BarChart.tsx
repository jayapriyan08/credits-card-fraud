import React, { useEffect, useRef } from 'react';
import { ChartData } from '../../types';

interface BarChartProps {
  data: ChartData[];
  title: string;
  className?: string;
  color?: string;
}

const BarChart: React.FC<BarChartProps> = ({ 
  data, 
  title, 
  className = '',
  color = '#3B82F6' // Default blue
}) => {
  const chartRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (!chartRef.current) return;
    
    // Clear previous chart
    while (chartRef.current.firstChild) {
      chartRef.current.removeChild(chartRef.current.firstChild);
    }
    
    // Find maximum value for scaling
    const maxValue = Math.max(...data.map(item => item.value));
    
    // Create chart container
    const chartContainer = document.createElement('div');
    chartContainer.className = 'flex items-end h-40 space-x-2';
    
    // Create bars
    data.forEach(item => {
      const percentage = (item.value / maxValue) * 100;
      
      // Container for bar and label
      const barContainer = document.createElement('div');
      barContainer.className = 'flex flex-col items-center flex-1';
      
      // Bar
      const bar = document.createElement('div');
      bar.className = 'w-full rounded-t transition-all duration-500 ease-in-out';
      bar.style.height = '0%'; // Start at 0 for animation
      bar.style.backgroundColor = color;
      
      // Value label
      const valueLabel = document.createElement('div');
      valueLabel.className = 'text-xs font-medium -mt-6 text-gray-700 opacity-0 transition-opacity duration-500';
      valueLabel.textContent = item.value.toString();
      
      // Category label
      const categoryLabel = document.createElement('div');
      categoryLabel.className = 'text-xs mt-1 text-gray-600 truncate w-full text-center';
      categoryLabel.textContent = item.label;
      
      // Add hover effect
      barContainer.addEventListener('mouseenter', () => {
        bar.className = 'w-full rounded-t transition-all duration-200 ease-in-out opacity-80';
        valueLabel.className = 'text-xs font-medium -mt-6 text-gray-700 opacity-100 transition-opacity duration-200';
      });
      
      barContainer.addEventListener('mouseleave', () => {
        bar.className = 'w-full rounded-t transition-all duration-200 ease-in-out opacity-100';
        valueLabel.className = 'text-xs font-medium -mt-6 text-gray-700 opacity-0 transition-opacity duration-200';
      });
      
      // Append elements
      barContainer.appendChild(valueLabel);
      barContainer.appendChild(bar);
      barContainer.appendChild(categoryLabel);
      chartContainer.appendChild(barContainer);
      
      // Animate bar height after a small delay
      setTimeout(() => {
        bar.style.height = `${percentage}%`;
      }, 100);
    });
    
    chartRef.current.appendChild(chartContainer);
  }, [data, color]);
  
  return (
    <div className={`flex flex-col ${className}`}>
      <h3 className="text-sm font-medium text-gray-700 mb-4">{title}</h3>
      <div ref={chartRef} className="w-full"></div>
    </div>
  );
};

export default BarChart;