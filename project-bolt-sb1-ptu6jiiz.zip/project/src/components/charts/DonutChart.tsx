import React, { useEffect, useRef } from 'react';
import { ChartData } from '../../types';

interface DonutChartProps {
  data: ChartData[];
  title: string;
  className?: string;
}

const DonutChart: React.FC<DonutChartProps> = ({ data, title, className = '' }) => {
  const chartRef = useRef<HTMLDivElement>(null);
  
  // Colors for different segments
  const colors = [
    '#3B82F6', // blue-500
    '#8B5CF6', // violet-500
    '#EC4899', // pink-500
    '#F97316', // orange-500
    '#10B981', // emerald-500
    '#6366F1', // indigo-500
    '#EF4444', // red-500
    '#F59E0B', // amber-500
  ];

  useEffect(() => {
    if (!chartRef.current) return;
    
    const width = chartRef.current.clientWidth;
    const height = chartRef.current.clientHeight;
    const radius = Math.min(width, height) / 2;
    const centerX = width / 2;
    const centerY = height / 2;
    
    // Clear previous chart
    while (chartRef.current.firstChild) {
      chartRef.current.removeChild(chartRef.current.firstChild);
    }
    
    // Create SVG element
    const svg = document.createElementNS('http://www.w3.org/2000/svg', 'svg');
    svg.setAttribute('width', '100%');
    svg.setAttribute('height', '100%');
    svg.setAttribute('viewBox', `0 0 ${width} ${height}`);
    
    // Calculate total value
    const total = data.reduce((sum, item) => sum + item.value, 0);
    
    // Create donut chart
    let startAngle = 0;
    const group = document.createElementNS('http://www.w3.org/2000/svg', 'g');
    group.setAttribute('transform', `translate(${centerX}, ${centerY})`);
    
    // Add segments
    data.forEach((item, index) => {
      const percentage = item.value / total;
      const endAngle = startAngle + percentage * 2 * Math.PI;
      
      // Calculate path
      const x1 = radius * Math.sin(startAngle);
      const y1 = -radius * Math.cos(startAngle);
      const x2 = radius * Math.sin(endAngle);
      const y2 = -radius * Math.cos(endAngle);
      
      const largeArcFlag = percentage > 0.5 ? 1 : 0;
      
      // Create path
      const path = document.createElementNS('http://www.w3.org/2000/svg', 'path');
      path.setAttribute('d', `M 0 0 L ${x1} ${y1} A ${radius} ${radius} 0 ${largeArcFlag} 1 ${x2} ${y2} Z`);
      path.setAttribute('fill', colors[index % colors.length]);
      path.setAttribute('stroke', 'white');
      path.setAttribute('stroke-width', '1');
      
      // Add hover effect
      path.setAttribute('class', 'transition-opacity duration-200 hover:opacity-80');
      
      // Add tooltip on hover
      path.addEventListener('mouseover', (e) => {
        const tooltip = document.createElement('div');
        tooltip.className = 'absolute bg-gray-800 text-white px-2 py-1 rounded text-xs';
        tooltip.style.left = `${e.pageX}px`;
        tooltip.style.top = `${e.pageY - 30}px`;
        tooltip.textContent = `${item.label}: ${item.value} (${Math.round(percentage * 100)}%)`;
        tooltip.id = 'chart-tooltip';
        document.body.appendChild(tooltip);
      });
      
      path.addEventListener('mousemove', (e) => {
        const tooltip = document.getElementById('chart-tooltip');
        if (tooltip) {
          tooltip.style.left = `${e.pageX}px`;
          tooltip.style.top = `${e.pageY - 30}px`;
        }
      });
      
      path.addEventListener('mouseout', () => {
        const tooltip = document.getElementById('chart-tooltip');
        if (tooltip) {
          document.body.removeChild(tooltip);
        }
      });
      
      group.appendChild(path);
      
      // Update start angle for next segment
      startAngle = endAngle;
    });
    
    // Create donut hole
    const innerCircle = document.createElementNS('http://www.w3.org/2000/svg', 'circle');
    innerCircle.setAttribute('cx', '0');
    innerCircle.setAttribute('cy', '0');
    innerCircle.setAttribute('r', `${radius * 0.6}`);
    innerCircle.setAttribute('fill', 'white');
    group.appendChild(innerCircle);
    
    svg.appendChild(group);
    chartRef.current.appendChild(svg);
    
    // Add legend
    const legend = document.createElement('div');
    legend.className = 'grid grid-cols-2 gap-2 mt-4 text-xs';
    
    data.forEach((item, index) => {
      const legendItem = document.createElement('div');
      legendItem.className = 'flex items-center';
      
      const colorIndicator = document.createElement('div');
      colorIndicator.className = 'w-3 h-3 mr-2 rounded-sm';
      colorIndicator.style.backgroundColor = colors[index % colors.length];
      
      const label = document.createElement('span');
      label.textContent = item.label;
      
      legendItem.appendChild(colorIndicator);
      legendItem.appendChild(label);
      legend.appendChild(legendItem);
    });
    
    chartRef.current.appendChild(legend);
  }, [data]);
  
  return (
    <div className={`flex flex-col ${className}`}>
      <h3 className="text-sm font-medium text-gray-700 mb-2">{title}</h3>
      <div 
        ref={chartRef} 
        className="w-full h-48 relative"
      ></div>
    </div>
  );
};

export default DonutChart;