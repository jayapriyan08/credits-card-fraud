import React, { useState } from 'react';
import { Transaction } from '../../types';
import Badge from '../ui/Badge';
import Button from '../ui/Button';
import { formatCurrency, formatDate, getRiskColor, getRiskLabel, getStatusBadgeClass } from '../../utils/formatters';
import { CreditCard, MapPin, AlertCircle, CheckCircle } from 'lucide-react';

interface TransactionTableProps {
  transactions: Transaction[];
}

const TransactionTable: React.FC<TransactionTableProps> = ({ transactions }) => {
  const [expandedId, setExpandedId] = useState<string | null>(null);

  const toggleExpand = (id: string) => {
    setExpandedId(expandedId === id ? null : id);
  };

  return (
    <div className="overflow-x-auto">
      <table className="min-w-full divide-y divide-gray-200">
        <thead className="bg-gray-50">
          <tr>
            <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
              Merchant
            </th>
            <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
              Amount
            </th>
            <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
              Date
            </th>
            <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
              Status
            </th>
            <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
              Risk
            </th>
            <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
              Actions
            </th>
          </tr>
        </thead>
        <tbody className="bg-white divide-y divide-gray-200">
          {transactions.map((transaction) => (
            <React.Fragment key={transaction.id}>
              <tr 
                className={`hover:bg-gray-50 transition-colors ${transaction.status === 'flagged' ? 'bg-yellow-50' : ''}`}
                onClick={() => toggleExpand(transaction.id)}
              >
                <td className="px-6 py-4 whitespace-nowrap">
                  <div className="flex items-center">
                    <div className="flex-shrink-0 h-10 w-10 bg-gray-100 rounded-full flex items-center justify-center">
                      <CreditCard className="h-5 w-5 text-gray-500" />
                    </div>
                    <div className="ml-4">
                      <div className="text-sm font-medium text-gray-900">{transaction.merchant}</div>
                      <div className="text-sm text-gray-500">{transaction.category}</div>
                    </div>
                  </div>
                </td>
                <td className="px-6 py-4 whitespace-nowrap">
                  <div className="text-sm font-medium text-gray-900">{formatCurrency(transaction.amount)}</div>
                  <div className="text-xs text-gray-500">Card ending in {transaction.cardLast4}</div>
                </td>
                <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                  {formatDate(transaction.date)}
                </td>
                <td className="px-6 py-4 whitespace-nowrap">
                  <Badge 
                    text={transaction.status.charAt(0).toUpperCase() + transaction.status.slice(1)} 
                    className={getStatusBadgeClass(transaction.status)}
                  />
                </td>
                <td className="px-6 py-4 whitespace-nowrap">
                  <Badge 
                    text={`${transaction.riskScore}% - ${getRiskLabel(transaction.riskScore)}`} 
                    className={getRiskColor(transaction.riskScore)}
                  />
                </td>
                <td className="px-6 py-4 whitespace-nowrap text-right text-sm font-medium">
                  <button
                    className="text-blue-600 hover:text-blue-900 focus:outline-none"
                    onClick={() => toggleExpand(transaction.id)}
                  >
                    {expandedId === transaction.id ? 'Hide details' : 'View details'}
                  </button>
                </td>
              </tr>
              {expandedId === transaction.id && (
                <tr className="bg-gray-50">
                  <td colSpan={6} className="px-6 py-4">
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      <div>
                        <h4 className="text-sm font-medium text-gray-700 mb-2">Transaction Details</h4>
                        <div className="space-y-2">
                          <div className="flex items-start">
                            <MapPin className="h-4 w-4 text-gray-400 mt-0.5 mr-2" />
                            <div>
                              <div className="text-sm font-medium text-gray-700">Location</div>
                              <div className="text-sm text-gray-500">{transaction.location}</div>
                            </div>
                          </div>
                          <div className="flex items-start">
                            <CreditCard className="h-4 w-4 text-gray-400 mt-0.5 mr-2" />
                            <div>
                              <div className="text-sm font-medium text-gray-700">Device</div>
                              <div className="text-sm text-gray-500">{transaction.deviceUsed}</div>
                            </div>
                          </div>
                          {transaction.notes && (
                            <div className="flex items-start">
                              <AlertCircle className="h-4 w-4 text-amber-500 mt-0.5 mr-2" />
                              <div>
                                <div className="text-sm font-medium text-gray-700">Notes</div>
                                <div className="text-sm text-amber-600">{transaction.notes}</div>
                              </div>
                            </div>
                          )}
                        </div>
                      </div>
                      <div>
                        <h4 className="text-sm font-medium text-gray-700 mb-2">Actions</h4>
                        <div className="space-y-2">
                          {transaction.status === 'flagged' && (
                            <>
                              <Button size="sm" className="mr-2">
                                <CheckCircle className="h-4 w-4 mr-1" />
                                Approve Transaction
                              </Button>
                              <Button variant="danger" size="sm">
                                <AlertCircle className="h-4 w-4 mr-1" />
                                Report Fraud
                              </Button>
                            </>
                          )}
                          {transaction.status === 'approved' && (
                            <Button variant="outline" size="sm">
                              <AlertCircle className="h-4 w-4 mr-1" />
                              Dispute Transaction
                            </Button>
                          )}
                          {transaction.status === 'declined' && (
                            <Button variant="outline" size="sm">
                              <CheckCircle className="h-4 w-4 mr-1" />
                              Allow Transaction
                            </Button>
                          )}
                        </div>
                      </div>
                    </div>
                  </td>
                </tr>
              )}
            </React.Fragment>
          ))}
        </tbody>
      </table>
    </div>
  );
};

export default TransactionTable;