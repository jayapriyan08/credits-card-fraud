import React from 'react';
import { Alert } from '../../types';
import { formatDate, getAlertTypeColor } from '../../utils/formatters';
import { AlertTriangle, MapPin, CreditCard, DollarSign } from 'lucide-react';

interface AlertsListProps {
  alerts: Alert[];
  onMarkAsRead: (id: string) => void;
}

const AlertsList: React.FC<AlertsListProps> = ({ alerts, onMarkAsRead }) => {
  const getAlertIcon = (type: string) => {
    switch (type) {
      case 'high_risk':
        return <AlertTriangle className={`h-5 w-5 ${getAlertTypeColor(type)}`} />;
      case 'unusual_location':
        return <MapPin className={`h-5 w-5 ${getAlertTypeColor(type)}`} />;
      case 'multiple_attempts':
        return <CreditCard className={`h-5 w-5 ${getAlertTypeColor(type)}`} />;
      case 'large_transaction':
        return <DollarSign className={`h-5 w-5 ${getAlertTypeColor(type)}`} />;
      default:
        return <AlertTriangle className={`h-5 w-5 ${getAlertTypeColor(type)}`} />;
    }
  };

  return (
    <div className="space-y-2">
      {alerts.length === 0 ? (
        <div className="text-center py-6 text-gray-500">
          No alerts at this time.
        </div>
      ) : (
        alerts.map((alert) => (
          <div 
            key={alert.id}
            className={`p-4 rounded-lg border transition-all duration-200 ${
              alert.isRead ? 'border-gray-200 bg-white' : 'border-red-100 bg-red-50'
            }`}
          >
            <div className="flex items-start">
              <div className="flex-shrink-0">
                {getAlertIcon(alert.type)}
              </div>
              <div className="ml-3 flex-1">
                <div className="flex items-center justify-between">
                  <p className={`text-sm font-medium ${alert.isRead ? 'text-gray-800' : 'text-red-800'}`}>
                    {alert.message}
                  </p>
                  <span className="text-xs text-gray-500">{formatDate(alert.date)}</span>
                </div>
                {!alert.isRead && (
                  <div className="mt-2">
                    <button
                      onClick={() => onMarkAsRead(alert.id)}
                      className="text-xs text-blue-600 hover:text-blue-800 font-medium"
                    >
                      Mark as read
                    </button>
                  </div>
                )}
              </div>
            </div>
          </div>
        ))
      )}
    </div>
  );
};

export default AlertsList;