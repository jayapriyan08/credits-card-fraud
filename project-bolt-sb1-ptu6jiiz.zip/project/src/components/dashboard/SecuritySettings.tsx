import React from 'react';
import { SecuritySetting } from '../../types';
import { Shield, Bell, MapPin, Smartphone, Globe } from 'lucide-react';

interface SecuritySettingsProps {
  settings: SecuritySetting[];
  onToggle: (id: string) => void;
}

const SecuritySettings: React.FC<SecuritySettingsProps> = ({ settings, onToggle }) => {
  const getSettingIcon = (name: string) => {
    if (name.includes('Location')) return <MapPin className="h-5 w-5 text-blue-500" />;
    if (name.includes('Transaction')) return <Bell className="h-5 w-5 text-purple-500" />;
    if (name.includes('International')) return <Globe className="h-5 w-5 text-green-500" />;
    if (name.includes('Device')) return <Smartphone className="h-5 w-5 text-orange-500" />;
    if (name.includes('SMS')) return <Bell className="h-5 w-5 text-red-500" />;
    return <Shield className="h-5 w-5 text-blue-500" />;
  };

  return (
    <div className="divide-y">
      {settings.map((setting) => (
        <div key={setting.id} className="py-4 flex items-center justify-between">
          <div className="flex items-start space-x-3">
            <div className="mt-0.5">
              {getSettingIcon(setting.name)}
            </div>
            <div>
              <h4 className="text-sm font-medium text-gray-900">{setting.name}</h4>
              <p className="text-sm text-gray-500">{setting.description}</p>
            </div>
          </div>
          <div className="flex-shrink-0">
            <button 
              type="button"
              role="switch"
              aria-checked={setting.isEnabled}
              className={`
                relative inline-flex h-6 w-11 flex-shrink-0 cursor-pointer rounded-full border-2 border-transparent 
                transition-colors duration-200 ease-in-out focus:outline-none focus:ring-2 focus:ring-blue-500 focus:ring-offset-2
                ${setting.isEnabled ? 'bg-blue-600' : 'bg-gray-200'}
              `}
              onClick={() => onToggle(setting.id)}
            >
              <span 
                className={`
                  pointer-events-none inline-block h-5 w-5 transform rounded-full bg-white shadow ring-0 
                  transition duration-200 ease-in-out
                  ${setting.isEnabled ? 'translate-x-5' : 'translate-x-0'}
                `}
              />
            </button>
          </div>
        </div>
      ))}
    </div>
  );
};

export default SecuritySettings;