import React, { useState } from 'react';
import Header from './components/layout/Header';
import Sidebar from './components/layout/Sidebar';
import Dashboard from './pages/Dashboard';
import Transactions from './pages/Transactions';
import Alerts from './pages/Alerts';
import Security from './pages/Security';
import Reports from './pages/Reports';

function App() {
  const [isSidebarOpen, setIsSidebarOpen] = useState(false);
  const [activeTab, setActiveTab] = useState('dashboard');
  
  const toggleSidebar = () => {
    setIsSidebarOpen(!isSidebarOpen);
  };
  
  // Render the appropriate content based on active tab
  const renderContent = () => {
    switch(activeTab) {
      case 'dashboard':
        return <Dashboard />;
      case 'transactions':
        return <Transactions />;
      case 'alerts':
        return <Alerts />;
      case 'security':
        return <Security />;
      case 'reports':
        return <Reports />;
      default:
        return <Dashboard />;
    }
  };

  return (
    <div className="min-h-screen bg-gray-50">
      <Header toggleSidebar={toggleSidebar} isSidebarOpen={isSidebarOpen} />
      
      <div className="flex h-[calc(100vh-4rem)]">
        <Sidebar 
          isOpen={isSidebarOpen} 
          activeTab={activeTab}
          setActiveTab={(tab) => {
            setActiveTab(tab);
            if (window.innerWidth < 768) {
              setIsSidebarOpen(false);
            }
          }}
        />
        
        <main className="flex-1 overflow-y-auto pb-10">
          {renderContent()}
        </main>
      </div>
      
      {/* Mobile sidebar backdrop */}
      {isSidebarOpen && (
        <div 
          className="md:hidden fixed inset-0 z-10 bg-gray-600 bg-opacity-75 transition-opacity"
          onClick={toggleSidebar}
        />
      )}
    </div>
  );
}

export default App;